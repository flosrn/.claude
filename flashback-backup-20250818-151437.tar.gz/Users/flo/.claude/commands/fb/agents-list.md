---
allowed-tools: Bash(flashback:*)
---

# 🤖 Available AI Agents

Lists all available Claude Code agents with descriptions and usage instructions.

CLAUDE: YOU MUST RUN THIS COMMAND AND RETURN THE COMPLETE LIST TO THE USER. DO NOT just acknowledge the command - EXECUTE IT AND SHOW THE RESULTS:

!`flashback agent --list`

CLAUDE: After running the command above, display the full output to the user. Never skip this step.