---
allowed-tools: Bash(flashback:*)
---

# 🎭 Available AI Personas

Lists all available AI personas with descriptions and usage instructions.

CLAUDE: YOU MUST RUN THIS COMMAND AND RETURN THE COMPLETE LIST TO THE USER. DO NOT just acknowledge the command - EXECUTE IT AND SHOW THE RESULTS:

!`flashback persona --list`

CLAUDE: After running the command above, display the full output to the user. Never skip this step.