## Discussion Topic
"{{TOPIC}}"

## Persona Responses
{{PERSONA_RESPONSES}}

## Your Task
Judge this AI discussion. Analyze each persona's position, identify agreements/disagreements, assign stance scores, and declare a winner based on strongest evidence and reasoning.

Return your judgment in this format:
- Summary: [Brief overview of the discussion]
- Winner: [Winning persona name]  
- Key Insights: [Important points discovered]