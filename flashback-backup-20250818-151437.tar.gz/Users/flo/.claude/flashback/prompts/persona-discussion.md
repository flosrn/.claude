## Discussion Topic
"{{TOPIC}}"

## Project Memory
{{PROJECT_MEMORY}}

## Current Working Plan  
{{WORKING_PLAN}}

## Recent Conversation Context
{{CONVERSATION_CONTEXT}}

## Your Task
Analyze the discussion topic using your specialized expertise. Provide your position and reasoning. This will be part of an AI discussion with other personas, so be clear about your stance and the evidence supporting it.